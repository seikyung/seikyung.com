// BSD License (http://www.galagosearch.org/license)

package org.galagosearch.exercises;

import java.io.IOException;
import org.galagosearch.core.parse.TagTokenizer;
import org.galagosearch.core.parse.UniversalParser;
import org.galagosearch.core.parse.WordCountReducer;
import org.galagosearch.core.parse.WordCounter;
import org.galagosearch.core.tools.BuildIndex;
import org.galagosearch.core.types.DocumentSplit;
import org.galagosearch.core.types.WordCount;
import org.galagosearch.tupleflow.Parameters;
import org.galagosearch.tupleflow.StandardStep;
import org.galagosearch.tupleflow.TextWriter;
import org.galagosearch.tupleflow.Utility;
import org.galagosearch.tupleflow.execution.ConnectionAssignmentType;
import org.galagosearch.tupleflow.execution.ConnectionPointType;
import org.galagosearch.tupleflow.execution.InputStep;
import org.galagosearch.tupleflow.execution.Job;
import org.galagosearch.tupleflow.execution.OutputStep;
import org.galagosearch.tupleflow.execution.Stage;
import org.galagosearch.tupleflow.execution.StageConnectionPoint;
import org.galagosearch.tupleflow.execution.Step;
import org.galagosearch.exercises.ZipfCount;
import org.galagosearch.tupleflow.InputClass;
import org.galagosearch.tupleflow.OutputClass;
import org.galagosearch.tupleflow.execution.ErrorStore;
import org.galagosearch.tupleflow.execution.JobExecutor;
import org.galagosearch.tupleflow.execution.Verified;

/**
 *
 */
public class ZipfsLaw1 {
    /**
     * Parses input text, then counts the word tokens.  The output is a
     * stream of WordCount tokens sorted by word.
     * 
     * @return A stage description for the wordCount stage.
     */
    public Stage getWordCountStage() {
        Stage stage = new Stage("wordCount");

        stage.add(new StageConnectionPoint(
                ConnectionPointType.Input,
                "splits", new DocumentSplit.FileNameStartKeyOrder()));
        stage.add(new StageConnectionPoint(
                ConnectionPointType.Output,
                "wordCounts", new WordCount.WordOrder()));

        stage.add(new InputStep("splits"));
        stage.add(new Step(UniversalParser.class));
        stage.add(new Step(TagTokenizer.class));
        stage.add(new Step(WordCounter.class));
        stage.add(Utility.getSorter(new WordCount.WordOrder(), WordCountReducer.class));
        stage.add(new OutputStep("wordCounts"));

        return stage;
    }

    /**
     * Gathers wordCount data from all the wordCounts stages
     * and computes count totals for each word.
     * 
     * @return A stage description for the reduceCounts stage.
     */
    public Stage getReduceCountsStage(String outputFile) {
        Stage stage = new Stage("reduceCounts");

        stage.add(new StageConnectionPoint( ConnectionPointType.Input, "wordCounts", new WordCount.WordOrder()));
        
        stage.add(new InputStep("wordCounts"));
        Parameters p = new Parameters();
        p.add("class", WordCount.class.getName());
        p.add("filename", outputFile);
        stage.add(new Step(TextWriter.class, p));

        return stage;
    }


    /**
     * Builds the entire job.
     */
    public Job getZipfJob(String outputFile, String[] inputs) throws IOException {
        Job job = new Job();
        BuildIndex b = new BuildIndex();

        job.add(b.getSplitStage(inputs));
        job.add(getWordCountStage());
        job.add(getReduceCountsStage(outputFile));

        job.connect("inputSplit", "wordCount", ConnectionAssignmentType.Each);
        job.connect("wordCount", "reduceCounts", ConnectionAssignmentType.Each);

        return job;
    }


    /**
     * Usage: 
	 * in your galagosearch/galagosearch-core/ folder,
	 * Type the following
	 * export CLASSPATH=target/appassembler/lib/antlr-2.7.7.jar:target/appassembler/lib/galagosearch-core-1.04.jar:target/appassembler/lib/galagosearch-tupleflow-1.04.jar:target/appassembler/lib/jetty-6.1.5.jar:target/appassembler/lib/jetty-embedded-6.1.5.jar:target/appassembler/lib/jetty-util-6.1.5.jar:target/appassembler/lib/jsp-api-2.1.jar:target/appassembler/lib/maven-metadata-appassembler.xml:target/appassembler/lib/servlet-api-2.5-6.1.5.jar:target/appassembler/lib/stringtemplate-3.0.jar:target/appassembler/lib/xmlenc-0.52.jar:target/classes

	 * Type the following
     * java org/galagosearch/exercises/ZipfsLaw1 ../corpus/after-wordcount-mapper ../corpus/wiki-small.corpus 
     */
    public static void main(String[] args) throws Exception {
        String outputFile = args[0];
        String[] inputFiles = Utility.subarray(args, 1);

        Job job = new ZipfsLaw1().getZipfJob(outputFile, inputFiles);
        ErrorStore store = new ErrorStore();
        JobExecutor.runLocally(job, store, true);

        if (store.hasStatements())
            System.err.println(store.toString());
    }
}
